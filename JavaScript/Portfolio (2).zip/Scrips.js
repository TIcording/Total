//1번
const con = document.querySelector(".navbar__menu");
const ba = document.querySelector(".navbar__toggle-btn");
function open() {
        if (con.style.display == 'none'){
            con.style.display = 'flex';
        }else{
            con.style.display = 'none';
        }
    window.onresize = function(){
        document.location.reload();
    };
}
ba.addEventListener('click', open)
//2번
const navLinks = document.querySelectorAll('nav ul li a');

navLinks.forEach(link => {
link.addEventListener('click', event => {
    event.preventDefault();
    const sectionId = link.getAttribute('href');
    const section = document.querySelector(sectionId);
    window.scrollTo({
    top: section.offsetTop,
    behavior: 'smooth'
    });
});
});
//3번
// HTML 
// 탭에 맞춰 해당하는 work__projects 클래스명 변경 필요
// 숫자 나오는 span태그 숫자 날려도됨
const list_of_project = ['all','front_end', 'back_end', 'AI']
const count_of_project = {'all':0, 'front_end':0, 'back_end':0, 'AI':0}
const project = document.querySelectorAll('.project')
const button = document.getElementsByClassName('category__btn');
// event 넣기
for (p of project) {
    p.addEventListener('mouseover', all_project(p))
}
// 개수 계산하기
function all_project(p) {
    const cl_list = p.classList
    for (let i = 1; i < list_of_project.length; i++){
        if (cl_list.contains(`${list_of_project[i]}`)){
            count_of_project['all'] += 1
            count_of_project[list_of_project[i]] += 1
        }
    }
    const num = document.getElementsByClassName('category__count')
    for (let i in num){
        num[i].innerHTML = `${count_of_project[list_of_project[i]]}`
    }
}
// 숫자 보이게 하기
for (let number of button){
    const count = number.getElementsByClassName('category__count')[0];
    number.addEventListener('mouseover', () => {
        count.style.opacity = 1;
    });
    number.addEventListener('mouseout', () => {
        count.style.opacity = 0;
    });
}
// 눌렀을 때 해당하는 것만 보이게 하기
for (let i = 0; i < button.length; i++) {
    button[i].addEventListener('click', function() {
        hide_and_seek(i);
    });
}
function hide_and_seek(num) {
    const projects = document.getElementsByClassName('project');
    for (let i = 0; i < projects.length; i++) {
        if (!projects[i].classList.contains(list_of_project[num])) {
            projects[i].style.display = 'none';
        }else{
            projects[i].style.display = 'flex';
        }
    }
}
//4번
const arrow = document.querySelector('.arrow-up');
const home = document.getElementById('home');

document.addEventListener('scroll', movetop);

function movetop() {
    if (window.scrollY > home.offsetHeight) {
    arrow.classList.add('visible');
    } else {
    arrow.classList.remove('visible');
    }
}

arrow.addEventListener('click', () => {
    home.scrollIntoView({ behavior: 'smooth' });
});





// 2 번 re
window.addEventListener('scroll', () => {
    const scroll = window.scrollY;
    if (scroll > home.offsetTop + home.offsetHeight) {
        btn.classList.add('visible')
    } else {
        btn.classList.remove('visible')
    }
    sections.forEach((data, i) => {
        if(scroll > data.offsetTop - 300) {
            document.querySelector('.active').classList.remove('active');
            navList[i].classList.add('active');
        }
    });
    if(scroll >= document.body.offsetHeight - window.innerHeight - 100){
        document.querySelector('.active').classList.remove('active');
        navList[navList.length - 1].classList.add('active');
    }
})

const section_li = document.querySelectorAll('.navbar__menu__item')
const li = document.querySelectorAll('section')


const section_home = document.getElementById('home')
const section_about = document.getElementById('about')
const section_skills = document.getElementById('skills')
const section_work = document.getElementById('work')
const section_testimonials = document.getElementById('testimonials')
const section_contact = document.getElementById('contact')
console.log(section_li[1])

// window.addEventListener('scroll', () => {
// if ( (window.offsetTop <= window.scrollY)){
//     section_li[0].classList.add("active")
// }
// else if ((section_home.offsetHeight-navbar.offsetHeight <= window.scrollY)){
//     section_li[1].classList.add("active")
// }
// else if (section_about.offsetHeight<=window.scrollY){
//     section_li[2].classList.add("active")
// }
// else if (section_skills.offsetHeight<=window.scrollY){
//     section_li[3].classList.add("active")
// }
// else if ( section_work.offsetHeight<=window.scrollY){
//     section_li[4].classList.add("active")
// }
// else if ( section_testimonials.offsetHeight<=window.scrollY){
//     section_li[5].classList.add("active")
// }
// }





